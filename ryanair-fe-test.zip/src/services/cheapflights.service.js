export const CheapFlightService = () => {
  //TODO: Write your own implementation
};

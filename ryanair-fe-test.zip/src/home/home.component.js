import template from './home.component.html';
import './home.component.scss';

export const HomeComponent = {
  template
};
